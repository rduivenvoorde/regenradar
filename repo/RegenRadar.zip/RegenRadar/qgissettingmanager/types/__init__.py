from bool import Bool
from color import Color
from double import Double
from integer import Integer
from stringlist import Stringlist
from string import String